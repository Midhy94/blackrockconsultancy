'use client'

import Image from 'next/image'
import { motion } from 'framer-motion'
import { UserPlus, FileCheck, Plane, Headphones } from 'lucide-react'

const services = [
  {
    icon: UserPlus,
    title: 'Recruitment for skilled and semi-skilled roles',
    description: 'Comprehensive talent sourcing and placement for various skill levels.',
  },
  {
    icon: FileCheck,
    title: 'Documentation and visa support',
    description: 'End-to-end assistance with paperwork and visa processing.',
  },
  {
    icon: Plane,
    title: 'Pre-departure orientation',
    description: 'Preparing candidates for their new roles and destinations.',
  },
  {
    icon: Headphones,
    title: 'Post-placement assistance',
    description: 'Ongoing support after deployment for smooth transition.',
  },
]

interface ServicesProps {
  showBanner?: boolean
}

export default function Services({ showBanner = true }: ServicesProps) {
  return (
    <section id="services" className="section-padding bg-white">
      <div className="container-custom">
        {showBanner && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="relative rounded-2xl overflow-hidden h-48 sm:h-64 mb-16"
          >
            <Image
              src="https://images.unsplash.com/photo-1497366216548-37526070297c?w=1200&q=80"
              alt="Modern office workspace"
              fill
              className="object-cover"
              sizes="100vw"
            />
            <div className="absolute inset-0 bg-dark/50 flex items-center justify-center">
              <div className="text-center text-white">
                <h2 className="font-heading font-bold text-3xl sm:text-4xl">
                  Our <span className="text-primary">Services</span>
                </h2>
                <p className="mt-2 text-white/90 max-w-xl mx-auto">
                  End-to-end recruitment and HR support for overseas placements
                </p>
              </div>
            </div>
          </motion.div>
        )}

        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {services.map((service, index) => (
            <motion.div
              key={service.title}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.1 }}
              className="group"
            >
              <div className="h-full p-6 rounded-2xl bg-light border border-transparent hover:border-primary/20 hover:bg-white hover:shadow-xl transition-all duration-300 cursor-default">
                <div className="w-14 h-14 rounded-xl bg-primary/10 flex items-center justify-center mb-4 group-hover:bg-primary group-hover:scale-110 transition-all duration-300">
                  <service.icon size={26} className="text-primary group-hover:text-white transition-colors" />
                </div>
                <h3 className="font-heading font-semibold text-lg text-dark mb-2 group-hover:text-primary transition-colors">{service.title}</h3>
                <p className="text-secondary text-sm leading-relaxed">{service.description}</p>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  )
}
